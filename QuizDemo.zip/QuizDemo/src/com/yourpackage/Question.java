package com.yourpackage;

import java.util.Map;

public class Question {
    private int id;
    private String question;
    private Map<Integer, String> answers;
    private int correctAnswerId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public Map<Integer, String> getAnswers() {
        return answers;
    }

    public void setAnswers(Map<Integer, String> answers) {
        this.answers = answers;
    }

    public int getCorrectAnswerId() {
        return correctAnswerId;
    }

    public void setCorrectAnswerId(int correctAnswerId) {
        this.correctAnswerId = correctAnswerId;
    }

    // Add any additional methods or constructors as needed

    public void displayInfo() {
        System.out.println("Question id: " + id);
        System.out.println("Question: " + question);
        System.out.println("Answers:");
        answers.forEach((id, answer) ->
                System.out.println("  " + id + ". " + answer));
    }
}