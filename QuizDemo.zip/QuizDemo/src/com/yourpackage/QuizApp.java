package com.yourpackage;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Scanner;

public class QuizApp {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Example: Display and answer questions interactively
        try (Scanner scanner = new Scanner(System.in)) {
            // Example: Display and answer questions interactively
            for (int i = 1; i <= 3; i++) {
                Question question = context.getBean("question" + i, Question.class);
                displayQuestion(question);
                
                // Get user input for the answer
                System.out.print("Enter your choice (1, 2, or 3): ");
                int selectedAnswerId = scanner.nextInt();
                
                boolean isCorrect = question.getCorrectAnswerId() == selectedAnswerId;
                
                if (isCorrect) {
                    System.out.println("Correct!\n");
                } else {
                    System.out.println("Incorrect! The correct answer is: " + question.getAnswers().get(question.getCorrectAnswerId()) + "\n");
                }
            }
            // Close the scanner
        }
    }

    private static void displayQuestion(Question question) {
        System.out.println("Question id: " + question.getId());
        System.out.println("Question: " + question.getQuestion());
        System.out.println("Answers:");
        question.getAnswers().forEach((id, answer) ->
                System.out.println("  " + id + ". " + answer));
    }
}